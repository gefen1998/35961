import { base44 } from './base44Client';


export const UserPathway = base44.entities.UserPathway;



// auth sdk:
export const User = base44.auth;